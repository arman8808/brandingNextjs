const companyData = {
  companyAddress: "A2 Khushnuma Complex, Meera Bai Marg, Lucknow, India",
  companyAddress2: "Sheikh Zayed Rd Dubai - United Arab Emirates",

  companyPhone2: "+971522945504",
  companyPhone: "+919919444434",

  companyEmail2: "admin@branding360.ae",
  companyEmail: "admin@branding360.in",

  companyFacebook: "https://www.facebook.com/branding360.in",
  companyInsta: "https://www.instagram.com/branding360.in/?hl=en",
  companyLinkedIn: "https://www.linkedin.com/company/branding-360/mycompany/",
};

export default companyData;
